# NOTES.md

## Project Overview

This project is a responsive WordPress website built primarily using Elementor. The website was developed with a focus on clean design, responsiveness, and performance while minimizing the use of additional plugins.

## Tech Stack

- WordPress
- Elementor
- HTML5
- CSS3
- JavaScript

## Time Taken

- **Completion Time:** 1 hour

## Project Structure

- Elementor page templates (.json)
- Custom CSS (where required)
- Responsive layouts for desktop, tablet, and mobile

## Features

- Responsive design
- Custom header and footer
- Optimized page layouts
- Mobile-friendly interface
- Clean and reusable sections
- Custom CSS for layouts not achievable with Elementor alone


